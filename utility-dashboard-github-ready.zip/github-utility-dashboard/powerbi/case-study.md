# Grid & Digital Operations — Executive Dashboard (Power BI)

A blended executive dashboard for a utility company, combining grid
reliability, financial performance, and safety KPIs with IT system
health and engineering delivery metrics — built for a controller-level
financial audience, with IT/engineering included as supporting detail
rather than equal billing.

**Tools:** Power BI Desktop, DAX, Power Query
**Domain:** Utility operations — grid reliability, financial variance
analysis, safety, and IT/engineering delivery
**Scale:** 5-table relational data model, 20+ custom DAX measures, fully
interactive report with cross-filtering across every table
**Built:** End-to-end in a single session — data model, relationships,
measures, visuals, theming, and layout, all built by hand

All data is synthetic — no real utility company data is used.

## The problem

Utility companies generate two kinds of executive-relevant data that
usually live in separate systems: **operational/reliability data** (grid
outages, safety incidents) and **financial data** (revenue, opex, capex
vs. budget), with **IT/engineering delivery metrics** as a third,
often-siloed layer. A controller reviewing monthly performance typically
has to manually reconcile numbers across multiple reports instead of
seeing one governed view.

## The solution

I designed a full star-schema data model and built the report from
scratch:

- **Data modeling** — related 5 fact tables (outages, financials,
  safety, IT metrics, engineering deployments) to a shared date
  dimension table, enabling a single date slicer to filter reliability,
  financial, safety, and IT data simultaneously despite each table
  having a different natural grain (daily, weekly, monthly).
- **DAX measures** — built 20+ measures from scratch, including
  industry-specific reliability indices (SAIDI/SAIFI, calculated from
  raw outage duration and customer-impact data), budget variance
  calculations (actual vs. budget for revenue and opex), and standard
  aggregations across every domain.
- **Controller-first layout** — headline KPI row leads with revenue,
  opex, and operating margin (each showing variance vs. budget), followed
  by an actual-vs-budget chart as the core visual. IT/engineering metrics
  are deliberately demoted to a small, visually quiet footer strip rather
  than competing with the financial story — matching how a controller
  actually reads a report, not a generic "everything is equally
  important" dashboard layout.
- **Interactivity** — a single date-range slicer cross-filters every
  visual on the page; clicking any bar or category (e.g., an outage
  cause) cross-filters the rest of the report automatically.
- **Custom theming** — built a custom Power BI theme (navy/gray palette)
  and positioned every visual to precise coordinates for a clean,
  professional, non-default look.

## Why this mattered

- **Domain-accurate metrics** — SAIDI/SAIFI aren't generic KPIs; they're
  the actual industry-standard reliability indices utilities report on,
  built here as real, from-scratch DAX calculations rather than
  placeholder numbers.
- **Audience-aware design** — the layout hierarchy (financials first, IT
  last) reflects a deliberate choice about who's actually reading this
  and what they care about most, not just "here's all the data."
- **Real relational modeling, not flat tables** — connecting 5 tables of
  different grains to one date dimension is standard data-warehouse star
  schema design, applied inside Power BI rather than a traditional SQL
  environment.
- **Built, not templated** — every relationship, measure, and visual
  position was created and debugged by hand in this session, including
  working through real issues (measure/column naming conflicts,
  percentage formatting edge cases, layout overlaps) rather than
  starting from a pre-built template.

## Skills demonstrated

- Star-schema data modeling and relationship design
- DAX measure development, including multi-step derived calculations
  (SAIDI/SAIFI built from supporting intermediate measures)
- Budget variance analysis (actual vs. budget reporting)
- Power Query data preparation and type correction
- Executive dashboard design with audience-specific information
  hierarchy (controller-first, not generic)
- Custom Power BI theme development (JSON theme files)
- Cross-filtering/interactive report design

---
*This is a personal portfolio project built with synthetic data to
demonstrate Power BI data modeling, DAX, and executive dashboard design
for the utility industry.*
