# Visual layout spec — Grid & Digital Operations Executive Dashboard

Paint-by-numbers spec for the dashboard you built tonight. Apply
`power_bi_theme.json` first (File > Import theme, or View > Themes >
Browse for themes), then place each visual using these exact positions.

**Canvas**: default 16:9 page size (1280 x 720px). Set page background to
`#F7F8FA` if the theme doesn't auto-apply it (Format page > Canvas
background).

All positions are `(x, y)` from the top-left corner, in pixels, set via
**Format pane > General > Properties > Position and size** on each
visual (click the visual, expand that section).

---

## 1. Title (text box)
- Position: `(24, 16)` — Size: `440 x 32`
- Text: "Grid & Digital Operations — Executive View" — 20px, Segoe UI
  Semibold, `#1B2430`

## 2. Date slicer
- Position: `(700, 16)` — Size: `556 x 40`
- Keep the "Between" range style you already have — no change needed

## 3. KPI card row (4 cards)
All at `y = 72`, height `100`, width `296` each, `16px` gaps:

| Card | x | Measure |
|---|---|---|
| Total Revenue | 24 | `Total Revenue` |
| Total Opex | 336 | `Total Opex` |
| Operating Margin % | 648 | `Operating Margin %` |
| SAIDI Minutes | 960 | `SAIDI Minutes` |

- White background, no border, square corners (reads more "enterprise"
  than heavily rounded)
- Callout value: 26px Segoe UI Semibold, `#1B2430`
- Category label: 12px Segoe UI, `#6B7280`

## 4. Revenue trend chart (line chart)
- Position: `(24, 188)` — Size: `608 x 240`
- X-axis: `Month`, Y-axis: `Total Revenue`
- Line color: navy `#1F3A5F`, 2px thickness, no markers

## 5. Outages by cause (bar chart)
- Position: `(648, 188)` — Size: `608 x 240`
- X-axis: `cause`, Y-axis: `Total Outage Count`
- Single navy bars, no legend needed (only one series)

## 6. Opex variance chart (actual vs. budget)
- Position: `(24, 444)` — Size: `1232 x 180`
- X-axis: `Month`, Y-axis: `Total Opex` + `Total Budget Opex`
- Turn the legend **on** for this one specifically (it's the only chart
  with two series) — Format > Legend > On, position Top
- Suggested colors: actual = navy `#1F3A5F`, budget = neutral gray
  `#6B7280` — keeps actual as the visually "louder" series since it's
  the number that matters most

## 7. IT/engineering footer (3 small cards)
All at `y = 640`, height `64`, width `400` each, `16px` gaps:

| Card | x | Measure |
|---|---|---|
| Avg IT Uptime % | 24 | `Avg IT Uptime %` |
| Total IT Incidents | 440 | `Total IT Incidents` |
| Avg On-Time Delivery % | 856 | `Avg On-Time Delivery %` |

- Keep these visually smaller/quieter than the top KPI row — smaller
  font (18px callout instead of 26px), same white background
- This is the "afterthought" section from the original design brief —
  don't let it compete visually with the financial story above it

---

## General polish rules
- **One accent color carries emphasis** — navy (`#1F3A5F`) for anything
  that matters most (actual opex/revenue, the #1 story). Gray for
  supporting/comparison data (budget line, IT footer).
- **Align everything to the same left edge** — title, KPI row, both mid
  charts, and the variance chart all start at `x = 24`. This single
  alignment choice does more for "looks professional" than any color
  choice.
- **Turn off every visual's default border/shadow** — the theme handles
  this globally, but double-check under Format > Effects on each visual.
- **Leave breathing room at the bottom** — don't stretch the footer row
  to fill the last 16px of canvas; a little margin reads as intentional.
