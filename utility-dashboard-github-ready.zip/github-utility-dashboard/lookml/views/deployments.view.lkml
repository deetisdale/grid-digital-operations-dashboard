view: deployments {
  sql_table_name: analytics.deployments ;;

  dimension_group: week {
    type: time
    timeframes: [raw, date, week, month, quarter, year]
    sql: ${TABLE}.week_start ;;
  }

  dimension: team {
    type: string
    sql: ${TABLE}.team ;;
  }

  dimension: deployments {
    type: number
    sql: ${TABLE}.deployments ;;
  }

  dimension: success_rate_pct {
    type: number
    value_format_name: percent_1
    sql: ${TABLE}.success_rate_pct ;;
  }

  dimension: lead_time_hours {
    type: number
    sql: ${TABLE}.lead_time_hours ;;
  }

  dimension: on_time_delivery_pct {
    type: number
    value_format_name: percent_1
    sql: ${TABLE}.on_time_delivery_pct ;;
  }

  measure: total_deployments {
    type: sum
    sql: ${deployments} ;;
  }

  measure: avg_success_rate_pct {
    type: average
    sql: ${success_rate_pct} ;;
    value_format_name: percent_1
  }

  measure: avg_lead_time_hours {
    type: average
    sql: ${lead_time_hours} ;;
    description: "Average time from code commit to production deployment"
  }

  measure: avg_on_time_delivery_pct {
    type: average
    sql: ${on_time_delivery_pct} ;;
    value_format_name: percent_1
  }
}
