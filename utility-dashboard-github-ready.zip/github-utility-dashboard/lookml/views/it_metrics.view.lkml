view: it_metrics {
  sql_table_name: analytics.it_metrics ;;

  dimension_group: reported {
    type: time
    timeframes: [raw, date, month, quarter, year]
    sql: ${TABLE}.date ;;
  }

  dimension: system {
    type: string
    sql: ${TABLE}.system ;;
  }

  dimension: uptime_pct {
    type: number
    value_format_name: percent_2
    sql: ${TABLE}.uptime_pct ;;
  }

  dimension: incidents {
    type: number
    sql: ${TABLE}.incidents ;;
  }

  dimension: mttr_minutes {
    type: number
    sql: ${TABLE}.mttr_minutes ;;
  }

  measure: avg_uptime_pct {
    type: average
    sql: ${uptime_pct} ;;
    value_format_name: percent_2
  }

  measure: total_incidents {
    type: sum
    sql: ${incidents} ;;
  }

  measure: avg_mttr_minutes {
    type: average
    sql: ${mttr_minutes} ;;
    description: "Mean time to resolution for IT incidents"
  }
}
