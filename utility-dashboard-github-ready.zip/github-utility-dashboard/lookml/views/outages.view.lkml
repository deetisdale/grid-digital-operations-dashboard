view: outages {
  sql_table_name: analytics.outages ;;

  dimension: outage_id {
    primary_key: yes
    type: number
    sql: ${TABLE}.outage_id ;;
  }

  dimension_group: outage {
    type: time
    timeframes: [raw, date, week, month, quarter, year]
    sql: ${TABLE}.date ;;
  }

  dimension: region {
    type: string
    sql: ${TABLE}.region ;;
  }

  dimension: cause {
    type: string
    sql: ${TABLE}.cause ;;
  }

  dimension: duration_minutes {
    type: number
    sql: ${TABLE}.duration_minutes ;;
  }

  dimension: customers_affected {
    type: number
    sql: ${TABLE}.customers_affected ;;
  }

  # Customer-minutes interrupted, the building block for SAIDI
  measure: total_customer_minutes_interrupted {
    type: sum
    sql: ${duration_minutes} * ${customers_affected} ;;
    description: "Sum of duration x customers affected — numerator for SAIDI"
  }

  measure: total_outage_count {
    type: count
    description: "Total number of outage events — numerator for SAIFI"
  }

  measure: avg_outage_duration_minutes {
    type: average
    sql: ${duration_minutes} ;;
  }

  measure: total_customers_affected {
    type: sum
    sql: ${customers_affected} ;;
  }

  # SAIDI/SAIFI require a customer-base denominator, joined in from a
  # service-territory table in production. Modeled here as a constant
  # for demonstration; production version would reference a customers view.
  measure: saidi_minutes {
    type: number
    sql: ${total_customer_minutes_interrupted} / NULLIF(${total_customers_in_territory}, 0) ;;
    description: "System Average Interruption Duration Index"
  }

  measure: saifi {
    type: number
    sql: ${total_outage_count} * 1.0 / NULLIF(${total_customers_in_territory}, 0) ;;
    description: "System Average Interruption Frequency Index"
  }

  measure: total_customers_in_territory {
    type: number
    sql: 450000 ;;
    description: "Placeholder territory customer count — replace with real customer count view in production"
  }
}
