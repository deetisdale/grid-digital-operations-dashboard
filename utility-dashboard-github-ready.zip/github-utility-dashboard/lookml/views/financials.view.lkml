view: financials {
  sql_table_name: analytics.financials ;;

  dimension_group: month {
    type: time
    timeframes: [raw, date, month, quarter, year]
    sql: ${TABLE}.month ;;
  }

  dimension: region {
    type: string
    sql: ${TABLE}.region ;;
  }

  dimension: revenue_usd {
    type: number
    value_format_name: usd_0
    sql: ${TABLE}.revenue_usd ;;
  }

  dimension: opex_usd {
    type: number
    value_format_name: usd_0
    sql: ${TABLE}.opex_usd ;;
  }

  dimension: capex_usd {
    type: number
    value_format_name: usd_0
    sql: ${TABLE}.capex_usd ;;
  }

  measure: total_revenue {
    type: sum
    sql: ${revenue_usd} ;;
    value_format_name: usd_0
  }

  measure: total_opex {
    type: sum
    sql: ${opex_usd} ;;
    value_format_name: usd_0
  }

  measure: total_capex {
    type: sum
    sql: ${capex_usd} ;;
    value_format_name: usd_0
  }

  measure: operating_margin_pct {
    type: number
    sql: (${total_revenue} - ${total_opex}) * 100.0 / NULLIF(${total_revenue}, 0) ;;
    value_format_name: percent_1
  }
}
