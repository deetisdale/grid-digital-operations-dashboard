view: safety {
  sql_table_name: analytics.safety ;;

  dimension_group: month {
    type: time
    timeframes: [raw, date, month, quarter, year]
    sql: ${TABLE}.month ;;
  }

  dimension: recordable_incidents {
    type: number
    sql: ${TABLE}.recordable_incidents ;;
  }

  dimension: near_misses {
    type: number
    sql: ${TABLE}.near_misses ;;
  }

  dimension: lost_time_incidents {
    type: number
    sql: ${TABLE}.lost_time_incidents ;;
  }

  measure: total_recordable_incidents {
    type: sum
    sql: ${recordable_incidents} ;;
  }

  measure: total_near_misses {
    type: sum
    sql: ${near_misses} ;;
  }

  measure: total_lost_time_incidents {
    type: sum
    sql: ${lost_time_incidents} ;;
  }
}
