# Grid & Digital Operations — Executive Dashboard (Looker/LookML)

A blended executive dashboard for a utility company, combining grid reliability,
financial performance, and safety KPIs with IT system health and engineering
delivery metrics — built for executive leadership and IT department heads who
need one view spanning both the business and the technology behind it.

Built with **LookML** (Looker's semantic modeling language), designed to sit on
top of a cloud data warehouse (BigQuery/Snowflake/Redshift). All data in this
repo is synthetic — no real utility company data is used.

## Why this exists

Most utility dashboards split into two silos: operational/business dashboards
for executives (outages, reliability, revenue, safety) and IT dashboards for
engineering leadership (uptime, incidents, delivery velocity). Leadership
teams that own both — increasingly common as utilities invest heavily in
digital infrastructure — end up stitching these together manually.

This project models both domains in one semantic layer and blends them into a
single executive dashboard, so a CIO or VP overseeing both grid operations and
digital systems gets one governed source of truth instead of two disconnected
tools.

## What's included

```
views/
  outages.view.lkml       Outage events; derives SAIDI/SAIFI reliability indices
  financials.view.lkml    Monthly revenue, opex, capex, operating margin by region
  safety.view.lkml        Recordable incidents, near misses, lost-time incidents
  it_metrics.view.lkml    IT system uptime, incident count, MTTR
  deployments.view.lkml   Engineering team deployment frequency, lead time, on-time delivery

models/
  utility_exec.model.lkml  Ties views into explores, defines caching/refresh policy

dashboards/
  exec_operations_dashboard.dashboard.lookml   The blended executive dashboard definition

data/
  generate_synthetic_data.py   Generates the synthetic CSVs the views are built against
  *.csv                        Generated synthetic dataset
```

## Key metrics modeled

**Executive/business**
- SAIDI / SAIFI (industry-standard grid reliability indices)
- Revenue, opex, capex, and operating margin by region
- Recordable safety incidents, near misses, lost-time incidents

**IT / engineering**
- System uptime % and incident count by system
- Mean time to resolution (MTTR)
- Deployment frequency, success rate, and lead time by team
- On-time delivery % by team

## Notes on the LookML

- `outages.view.lkml` derives SAIDI/SAIFI from customer-minutes-interrupted
  and outage counts. The customer-base denominator is modeled as a constant
  for this demo; a production version would join a real customer/territory
  view.
- The dashboard LookML wires cross-filtering (`listen:`) across date range and
  region so executives can slice the entire blended view consistently.
- `persist_with` and a `datagroup` are defined to keep dashboard load times
  reasonable at the scale a real utility's data volume would require.

## Running this for real

This repo is the LookML layer only — to actually run it, you'd need:
1. A Looker instance connected to a warehouse (BigQuery, Snowflake, Redshift, etc.)
2. The synthetic CSVs loaded into warehouse tables matching the `sql_table_name`
   references in each view (or swap in real, permissioned data)
3. This repo added as a LookML project in that Looker instance

---
*This is a personal portfolio project built with synthetic data to demonstrate LookML data modeling and executive dashboard design for the utility industry.*
