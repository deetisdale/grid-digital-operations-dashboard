connection: "warehouse_connection"

include: "/views/*.view.lkml"

datagroup: utility_exec_default_datagroup {
  sql_trigger: SELECT MAX(date) FROM analytics.outages ;;
  max_cache_age: "24 hours"
}

persist_with: utility_exec_default_datagroup

explore: outages {
  label: "Grid Reliability"
  description: "Outage events and reliability indices (SAIDI/SAIFI) by region and cause"
}

explore: financials {
  label: "Financial Performance"
  description: "Revenue, opex, capex, and margin by region and month"
}

explore: safety {
  label: "Safety"
  description: "Recordable incidents, near misses, and lost-time incidents"
}

explore: it_metrics {
  label: "IT System Health"
  description: "Uptime, incident count, and MTTR by system"
}

explore: deployments {
  label: "Engineering Delivery"
  description: "Deployment frequency, success rate, lead time, and on-time delivery by team"
}
