"""
Generates realistic synthetic data for a utility company executive dashboard.
Covers grid reliability, financials, safety, and IT/dev department metrics.
All data is synthetic - no real utility company data is used.
"""
import csv
import random
from datetime import date, timedelta

random.seed(42)

REGIONS = ["North", "South", "East", "West", "Central"]
CAUSES = ["Weather", "Equipment failure", "Vegetation", "Vehicle accident", "Planned maintenance", "Animal contact"]
IT_SYSTEMS = ["Outage Management System", "Customer Billing Platform", "SCADA", "Mobile Workforce App", "Customer Portal"]
DEV_TEAMS = ["Grid Analytics", "Customer Experience", "Field Operations Tools", "Data Platform", "Core Billing"]

START = date(2024, 1, 1)
END = date(2025, 12, 31)


def daterange(start, end):
    days = (end - start).days
    for i in range(days + 1):
        yield start + timedelta(days=i)


# 1. Outage events (drives SAIDI/SAIFI reliability metrics)
with open("outages.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["outage_id", "date", "region", "duration_minutes", "customers_affected", "cause"])
    oid = 1
    for d in daterange(START, END):
        n_outages = random.choices([0, 1, 2, 3], weights=[55, 30, 10, 5])[0]
        for _ in range(n_outages):
            w.writerow([
                oid, d.isoformat(), random.choice(REGIONS),
                random.randint(15, 480),
                random.randint(20, 8000),
                random.choice(CAUSES),
            ])
            oid += 1

# 2. Monthly financials by region
with open("financials.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["month", "region", "revenue_usd", "opex_usd", "capex_usd"])
    m = date(2024, 1, 1)
    while m <= END:
        for r in REGIONS:
            base = random.uniform(8_000_000, 15_000_000)
            w.writerow([
                m.isoformat(), r,
                round(base, 2),
                round(base * random.uniform(0.55, 0.7), 2),
                round(base * random.uniform(0.1, 0.25), 2),
            ])
        # next month
        m = date(m.year + (1 if m.month == 12 else 0), 1 if m.month == 12 else m.month + 1, 1)

# 3. Safety incidents (monthly)
with open("safety.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["month", "recordable_incidents", "near_misses", "lost_time_incidents"])
    m = date(2024, 1, 1)
    while m <= END:
        w.writerow([
            m.isoformat(),
            random.randint(0, 4),
            random.randint(2, 15),
            random.randint(0, 2),
        ])
        m = date(m.year + (1 if m.month == 12 else 0), 1 if m.month == 12 else m.month + 1, 1)

# 4. IT system uptime/incidents (daily, per system)
with open("it_metrics.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["date", "system", "uptime_pct", "incidents", "mttr_minutes"])
    for d in daterange(START, END):
        if d.day != 1:  # sample monthly-ish to keep file smaller but still daily-capable
            continue
        for s in IT_SYSTEMS:
            incidents = random.choices([0, 1, 2, 3], weights=[60, 25, 10, 5])[0]
            w.writerow([
                d.isoformat(), s,
                round(random.uniform(99.5, 99.99) if incidents == 0 else random.uniform(97.5, 99.5), 3),
                incidents,
                random.randint(10, 240) if incidents else 0,
            ])

# 5. Dev team delivery metrics (weekly)
with open("deployments.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["week_start", "team", "deployments", "success_rate_pct", "lead_time_hours", "on_time_delivery_pct"])
    d = START
    while d <= END:
        for t in DEV_TEAMS:
            w.writerow([
                d.isoformat(), t,
                random.randint(1, 12),
                round(random.uniform(85, 100), 1),
                round(random.uniform(4, 72), 1),
                round(random.uniform(70, 100), 1),
            ])
        d += timedelta(days=7)

print("Synthetic data generated.")
