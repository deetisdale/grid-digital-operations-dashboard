- dashboard: exec_grid_and_digital_operations
  title: "Grid & Digital Operations — Executive View"
  layout: newspaper
  description: >
    Blended executive dashboard combining grid reliability, financial performance,
    safety, and IT/engineering delivery metrics into a single monthly view for
    executive leadership and IT department heads.

  filters:
  - name: date_range
    title: "Date Range"
    type: field_filter
    default_value: "12 months"
    explore: outages
    field: outages.outage_date

  - name: region
    title: "Region"
    type: field_filter
    default_value: ""
    explore: outages
    field: outages.region

  elements:
  - title: "SAIDI (System Average Interruption Duration)"
    name: saidi_tile
    explore: outages
    type: single_value
    measures: [outages.saidi_minutes]
    listen:
      date_range: outages.outage_date
      region: outages.region

  - title: "SAIFI (System Average Interruption Frequency)"
    name: saifi_tile
    explore: outages
    type: single_value
    measures: [outages.saifi]
    listen:
      date_range: outages.outage_date
      region: outages.region

  - title: "Outages by Cause"
    name: outages_by_cause
    explore: outages
    type: looker_bar
    dimensions: [outages.cause]
    measures: [outages.total_outage_count]
    sorts: [outages.total_outage_count desc]
    listen:
      date_range: outages.outage_date
      region: outages.region

  - title: "Revenue & Operating Margin by Month"
    name: revenue_trend
    explore: financials
    type: looker_line
    dimensions: [financials.month_month]
    measures: [financials.total_revenue, financials.operating_margin_pct]
    listen:
      date_range: financials.month_date

  - title: "Safety: Recordable Incidents vs Near Misses"
    name: safety_trend
    explore: safety
    type: looker_column
    dimensions: [safety.month_month]
    measures: [safety.total_recordable_incidents, safety.total_near_misses]
    listen:
      date_range: safety.month_date

  - title: "IT System Uptime by System"
    name: it_uptime_tile
    explore: it_metrics
    type: looker_grid
    dimensions: [it_metrics.system]
    measures: [it_metrics.avg_uptime_pct, it_metrics.total_incidents, it_metrics.avg_mttr_minutes]
    sorts: [it_metrics.avg_uptime_pct asc]
    listen:
      date_range: it_metrics.reported_date

  - title: "Engineering Delivery: On-Time % by Team"
    name: delivery_by_team
    explore: deployments
    type: looker_bar
    dimensions: [deployments.team]
    measures: [deployments.avg_on_time_delivery_pct, deployments.avg_success_rate_pct]
    sorts: [deployments.avg_on_time_delivery_pct desc]
    listen:
      date_range: deployments.week_date

  - title: "Deployment Lead Time Trend"
    name: lead_time_trend
    explore: deployments
    type: looker_line
    dimensions: [deployments.week_week]
    measures: [deployments.avg_lead_time_hours]
    listen:
      date_range: deployments.week_date
